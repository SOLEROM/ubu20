#!/bin/bash

sleep 20 && sh -c "conky -c ~/.Conky/conkyx/conkyrc"
